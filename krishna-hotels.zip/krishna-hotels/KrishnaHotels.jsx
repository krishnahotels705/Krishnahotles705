import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function KrishnaHotels() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-white p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold text-blue-800 mb-2">Krishna Hotels</h1>
        <p className="text-lg text-gray-700">Your perfect hill station getaway</p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-4">Welcome to Krishna Hotels</h2>
            <p className="text-gray-700">
              Enjoy the serene beauty of the hills with a comfortable and peaceful stay at Krishna Hotels.
              We offer cozy rooms, friendly service, and the perfect base to explore the surrounding nature.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-4">Contact & Booking Inquiry</h2>
            <form className="grid gap-4">
              <Input type="text" placeholder="Your Name" required />
              <Input type="email" placeholder="Your Email" required />
              <Textarea placeholder="Your Message or Booking Inquiry" required />
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                Send Inquiry
              </Button>
            </form>
          </CardContent>
        </Card>
      </section>

      <footer className="text-center text-sm text-gray-500">
        &copy; {new Date().getFullYear()} Krishna Hotels. All rights reserved.
      </footer>
    </div>
  );
}